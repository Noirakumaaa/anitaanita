import tkinter as tk

# Function to add text with margin
def add_text_with_margin():
    text = "Your text goes here\n"  # Add a new line for spacing
    output_text.insert(tk.END, text)

# Create a tkinter window
root = tk.Tk()

# Create a Text widget
output_text = tk.Text(root, wrap="word", padx=10, pady=10)  # Add padding to all sides
output_text.pack()

# Button to add text with margin
add_text_button = tk.Button(root, text="Add Text with Margin", command=add_text_with_margin)
add_text_button.pack()

root.mainloop()
