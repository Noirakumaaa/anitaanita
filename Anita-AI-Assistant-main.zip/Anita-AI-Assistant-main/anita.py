import customtkinter as ctk
from datetime import datetime
import openai
import sqlite3
import speech_recognition as sr
from gtts import gTTS
import threading
import time
import pygame
import tempfile
import PyPDF2
from PIL import Image, ImageTk
import random


#source /home/anita/Desktop/Anita/Anita-Ai-Assistant/bin/activate
#python3 anita.py
class AnitaSystem:
    def __init__(self):
        # File paths
        self.anita_instruction = "instruction.txt"
        self.chat_history_file = "chathistory.txt"
        self.orf_file = "orf.txt"
        self.bg_image = "ANITA.png"
        self.mic_image = "Mic.png"
        self.mic_mute_image = "Mic mute.png"
        self.orf = self.extract_text_pdf("ORF.pdf")
        #api
        openai.api_key = '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'

        # Initialize speech recognizer and pygame mixer
        self.r = sr.Recognizer()
        self.chooseMic = None
        pygame.mixer.init()

        # Initialize variables
        self.live_transcription = ""
        self.speech_recognition_active = False
        self.response_mic_on = True
        self.voice_Activation = [
                                    "hey anita",
                                    "anita",
                                    "hi anita", 
                                    "hii anita",
                                    "hey jarvis", 
                                    "windows on", 
                                    "arise"]  # Keywords for voice activation
        self.voice_Deactivation = [
                                    "anita off", 
                                    "anita turn off", 
                                    "anita shutdown", 
                                    "anita turnoff"] #Keywords for voice deactivation
        self.greetings = [
                                "Hello! How can I assist you today?\n",
                                "Good day! How may I help you?\n",
                                "Hi there! What can I do for you?\n",
                                "Greetings! Is there anything I can assist you with?\n",
                                "Welcome! How can I be of service?\n",
                                "Hey! What brings you here?\n",
                                "Hi! How can I make your day better?\n",
                                "Hello! Ready to tackle any challenges together?\n",
                                "Good to see you! How can I assist you today?\n",
                                "Hey! Let's make today great together! How can I assist?\n",
                                "Bonjour!\n"
                            ]
    # Start the voice activation
        self.voice_Activation_On = True
        voice_activation_thread = threading.Thread(target=self.voiceActivation)# Correct method name
        voice_activation_thread.daemon = True  # Set the thread as a daemon so it exits when the main program exits
        voice_activation_thread.start()

        # Get current time and date
        self.current_time = datetime.now().strftime("%I:%M:%S %p")
        self.current_date = datetime.now().strftime("%A, %B %d, %Y")
        self.timeDate = f'The current time is {self.current_time} and the date is {self.current_date}'

        # Initialize GUI components
        self.root = ctk.CTk()
        self.root.title("Voice Assistant")
        self.root.configure(bg="gray63")
        self.window_width, self.window_height = 1024, 600
        self.screen_width = self.root.winfo_screenwidth()
        self.screen_height = self.root.winfo_screenheight()
        self.x = max((self.screen_width - self.window_width) // 2, 0)
        self.y = max((self.screen_height - self.window_height) // 2, 0)
        self.root.geometry(f'{self.window_width}x{self.window_height}+{self.x}+{self.y}')

        #self.root.overrideredirect(True)

        self.background_image = ImageTk.PhotoImage(Image.open(self.bg_image))
        canvas = ctk.CTkCanvas(self.root,
                            width=1275,
                            height=745,
                            highlightthickness=3,
                            highlightbackground="black")
        canvas.create_image(0, 0, anchor=ctk.NW, image=self.background_image)
        canvas.place(x=0, y=0)

        self.output_textbox = ctk.CTkTextbox(self.root,
                                            width=500,
                                            height=475,
                                            bg_color="black",  # Set bg_color to empty string for transparency
                                            fg_color="white",
                                            text_color="black",
                                            corner_radius=20,
                                            border_color="black",
                                            border_width=2,  # Set border_width to 0 for no border
                                            font=("Helvetica", 30, "bold"),
                                            pady=20,
                                            padx=20)  # Set highlightthickness to 0
        self.output_textbox.place(x=510, y=10) 


        self.microphone_image = ctk.CTkImage(Image.open(self.mic_image),
                                             size=(65, 65))
        self.microphone_mute_image = ctk.CTkImage(Image.open(self.mic_mute_image),
                                                  size=(65, 70))
        self.speak_button = ctk.CTkButton(self.root, 
                                          text = "",
                                          width = 110,
                                          height = 75,
                                          corner_radius = 10,
                                          border_width = 3,
                                          border_color="black",
                                          image=self.microphone_image,  
                                          command=self.start_listening,)
        self.speak_button.place(x=712, y=505)
        #self.speak_button.pack()

        self.stop_speaking_button = ctk.CTkButton(self.root,                                                text="Stop Speaking",
                                                  
                                                text_color="black",
                                                font=("Helvetica", 15, "bold"),
                                                border_width=3,
                                                width=150,
                                                height=76,
                                                corner_radius = 10,
                                                border_color="black",
                                                command=self.stop_speech)
        self.stop_speaking_button.place(x=850, y=505)
          # Adjusted position

        self.stopListening = ctk.CTkButton(self.root,
                                        text="Stop Listening",
                                        text_color="black",
                                        font=("Helvetica", 15, "bold"),
                                        border_width=3,
                                        width=150,
                                        height=76,
                                        border_color="black",
                                        corner_radius = 10,
                                        command=self.stop_listening)
        self.stopListening.place(x=525, y=505 ) # Adjusted position

        self.is_listening = False

        # Create database connection and cursor
        self.conn = sqlite3.connect('Conversations.db', check_same_thread=False)
        self.cursor = self.conn.cursor()
        self.create_table()  # Create table if not exists

        # Start GUI main loop
        self.root.mainloop()

    def writeOrf_to_text(self, text):
        with open(self.orf_file, 'w')as file:
            file.write(text)

    def AnitaFiledata(self, txtFile):
        try:
            with open(txtFile, 'r') as file:
                return file.read()
        except FileNotFoundError:
            return "File not found."
        except PermissionError:
            return "Permission denied."
        except Exception as e:
            return f"An error occurred: {e}"

    # Function to extract text from a PDF file
    def extract_text_pdf(self, pdf_path):
        text = ""
        try:
            with open(pdf_path, 'rb') as pdf_file:
                pdf_reader = PyPDF2.PdfReader(pdf_file)
                for page_num in range(len(pdf_reader.pages)):
                    page = pdf_reader.pages[page_num]
                    text += page.extract_text()
        except FileNotFoundError:
            return "File not found."
        
        return text        

    def create_table(self):
        # Create users table if not exists
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS users 
                    (id INTEGER PRIMARY KEY, name TEXT, chat TEXT, time TEXT, date TEXT)''')
        self.conn.commit()

    def save_to_database(self, user, anita, time, date):
        try:
            # Insert user and Anita chats
            self.cursor.execute("INSERT INTO users (name, chat, time, date) VALUES (?, ?, ?, ?), (?, ?, ?, ?)",
                                ('User', user, time, date, 'Anita', anita, time, date))
            # Commit changes to database
            self.conn.commit()
            # Update chat history
            self.memoryHandler(self.cursor)
            self.get_chathistory(self.cursor)
        except sqlite3.Error as e:
            print("Error saving to database:", e)

    def memoryHandler(self, cursor):
        try:
            # Execute the SQL query to get the maximum ID
            cursor.execute("SELECT MAX(id) FROM users")
            max_id = cursor.fetchone()[0]

            # Execute the SQL query to get the count of IDs
            cursor.execute("SELECT COUNT(id) FROM users")
            count = cursor.fetchone()[0]

            if max_id is not None and count is not None and count >= 300:
                cursor.execute("DELETE FROM users WHERE id <= ?", (max_id - 300,))
                self.conn.commit()

        except sqlite3.Error as e:
            print("Error in memoryHandler:", e)

    # Function to retrieve chat history from the database and write it to a file
    def get_chathistory(self, cursor):
        cursor.execute("SELECT * FROM users")
        rows = cursor.fetchall()
        with open(self.chat_history_file, 'w') as Wfile:
            instruction = "Read this conversation and memories it:\n"  # Instruction for the chat history data
            Wfile.write(instruction)
            for row in rows:
                Wfile.write(str(row) + '\n')  # Write each row to the file
                
    def changeMic(self):
        for index, name in enumerate(sr.Microphone.list_microphone_names()):  # Check available microphones
                print(f"Microphone {index}: {name}")
        self.chooseMic = 1 #default mic

    # Function to recognize speech
    def recognize_speech(self, audio):
        try:
        # Extract text from ORF PDF
            a = threading.Thread(target=self.writeOrf_to_text, args=(self.orf,))
            a.start()

            # Recognize user speech input
            user_speech_input = self.r.recognize_google(audio)
            user_input = "\nUser: " + user_speech_input + "\n"
            b = threading.Thread(target=self.write_to_textbox, args=(user_input,))
            b.start()

            # Generate response using OpenAI ChatCompletion
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": self.timeDate},  # Include time and date
                    {"role": "system", "content": self.AnitaFiledata(self.anita_instruction)},  # Instruction
                    {"role": "system", "content": self.AnitaFiledata(self.chat_history_file)},  # Chat history
                    {"role": "system", "content": self.AnitaFiledata(self.orf_file)},  # ORF data
                    {"role": "user", "content": user_speech_input},  # User input
                ],
            )

            response_text = response.choices[0].message["content"]
            self.response_mic_on = False
            c = threading.Thread(target=self.speak_response, args=(response_text,))
            c.start()
            self.response_mic_on = True
            anita_response = "\nAnita : " + response_text + "\n"
            d = threading.Thread(target=self.write_to_textbox, args=(anita_response,))
            d.start()

            # Wait for all threads to finish
            a.join()
            b.join()
            c.join()
            d.join()

            # Check if the response contains "anita off" to stop listening
            for x in self.voice_Deactivation:
                if x in user_speech_input:
                    self.speech_recognition_active = False
                    self.stop_listening()
                    self.voice_Activation_On = True
                    self.voiceActivation()
            print(threading.enumerate())

            self.save_to_database(self.live_transcription, response_text, self.current_time, self.current_date)

        except sr.UnknownValueError:
            #self.draw_red_dot()
            self.change_button_color_red()
        except sr.RequestError as e:
            print(f"Could not request results; {e}")

    # Function to write text to the textbox
    def write_to_textbox(self, text):
        # Set state to NORMAL to allow modifications
        self.output_textbox.configure(state=ctk.NORMAL)
        
        # Insert new text
        self.output_textbox.insert("2.0", text)
        
        # Set state back to DISABLED to prevent further modifications
        self.output_textbox.configure(state=ctk.DISABLED)
        
        
        # Ensure that the scrollbar is scrolled to the end
        self.output_textbox.see("1.0")


    # Function to speak the response
    def speak_response(self, response_text):
        #self.draw_red_dot()
        self.change_button_color_red()
        tts = gTTS(text=response_text, lang='en')

        with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as tmp_file:
            temp_file_name = tmp_file.name
            tts.save(temp_file_name)

        pygame.mixer.music.load(temp_file_name)
        pygame.mixer.music.play()
    

        while pygame.mixer.music.get_busy():
            time.sleep(0.1)

        # Stop the playback explicitly
        pygame.mixer.music.stop()
        #self.draw_green_dot()

        self.change_button_color

    # Function to start/stop listening

    def perform_speech_recognition(self):
        # Start the speech recognition process
        while self.response_mic_on:
            with sr.Microphone(device_index=self.chooseMic) as source:
                self.r.adjust_for_ambient_noise(source)
                self.speech_recognition_active = True
                while self.speech_recognition_active:
                    try:
                        print("Say something... Main mic")
                        #self.draw_green_dot()
                        self.change_button_color()
                        audio = self.r.listen(source, timeout=15, phrase_time_limit=3)
                        
                        self.recognize_speech(audio)
                        # Process the audio in a separate thread
                        #recognition_thread = threading.Thread(target=self.recognize_speech, args=(self.r, audio))
                        #recognition_thread.start()
                        #recognition_thread.join()  # Wait for the recognition thread to finish

                    except sr.WaitTimeoutError:
                        print("bagal mag salita")

            self.r.energy_threshold = 4000
            self.speak_button.configure(text="")

    def voiceActivation(self):
        while self.voice_Activation_On:  # Continuous loop for listening
            with sr.Microphone(device_index=self.chooseMic) as source:
                print("voice activated")
                self.r.adjust_for_ambient_noise(source)
                self.speech_recognition_active = True
                try:
                    print("Say something... Voice Activation")
                    self.change_button_color()
                    #self.draw_green_dot()
                    audio = self.r.listen(source, timeout=15, phrase_time_limit=2)
                    if audio is not None:
                        text = self.r.recognize_google(audio)
                        for x in self.voice_Activation:
                            if x.lower() in text:
                                greetingsNum = random.randrange(0,len(self.greetings))
                                anitaR = self.greetings[greetingsNum]
                                anitaS = "Anita : " + anitaR
                                self.write_to_textbox(anitaS)
                                self.speak_response(anitaR)
                                self.start_listening()
                except sr.WaitTimeoutError:
                    pass
                except sr.UnknownValueError:
                    #self.draw_red_dot()
                    self.change_button_color_red()
                except sr.RequestError as e:
                    print(f"An error occurred during speech recognition: {e}")
  
    def start_listening(self):
        self.is_listening = True
        self.voice_Activation_On = False
        self.change_button_color()
                # Create a new thread for speech recognition
        speech_thred = threading.Thread(target=self.perform_speech_recognition)
        speech_thred.start()

    def change_button_color(self):
        self.speak_button.configure(fg_color = "green", image=self.microphone_image )

    def change_button_color_red(self):
        self.speak_button.configure(fg_color = "#D21404", image=self.microphone_mute_image)

    def stop_listening(self):
        self.is_listening = False
        self.response_mic_on = False
        self.speak_button.configure(text="")
        #self.draw_red_dot()  # Update UI
        self.change_button_color_red()

    # To stop anita from speaking
    def stop_speech(self):
        pygame.mixer.music.stop()

    # Function to run the Anita system
    def anitaRun(self):
        self.root.mainloop()


# Create an instance of AnitaSystem and start the voice assistant
anita_system = AnitaSystem()
anita_system.anitaRun()